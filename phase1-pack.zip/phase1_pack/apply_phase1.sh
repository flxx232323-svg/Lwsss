#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
#  apply_phase1.sh — المرحلة 1: سجل الأوامر + قائمة تيليجرام + أداة التدقيق
#  التشغيل من جذر المشروع:   bash phase1_pack/apply_phase1.sh
#
#  1) فحوص أولية (لا يُلمس شيء قبل اجتيازها)
#  2) نسخة احتياطية في backups/phase1-<وقت>/ لكل ملف سيتأثر
#  3) نسخ الملفات الجديدة + تعديل index.js بسطر واحد
#  4) فحص الصياغة + تشغيل الاختبارات + أداة التدقيق
#  عند أي فشل: استرجاع تلقائي كامل (الملفات القديمة تعود والجديدة تُحذف).
# ════════════════════════════════════════════════════════════════
set -uo pipefail

PACK="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(pwd)"
STAMP="$(date +%Y%m%d%H%M%S)"
BK="$ROOT/backups/phase1-$STAMP"
LOG="$BK/checks.log"

say() { printf '\033[1;36m%s\033[0m\n' "$1"; }
ok()  { printf '\033[1;32m✔ %s\033[0m\n' "$1"; }
bad() { printf '\033[1;31m✘ %s\033[0m\n' "$1" >&2; }

NEW_FILES=(
  "utils/command_registry.js"
  "utils/command_menu.js"
  "scripts/lib/command_scanner.js"
  "scripts/audit_commands.js"
  "test/command_registry.test.js"
  "docs/PHASE0_AUDIT_REPORT.md"
)
CREATED=()

rollback() {
  bad "فشلت المرحلة 1 — جارٍ الاسترجاع الكامل..."
  if [ -d "$BK" ]; then
    ( cd "$BK" && find . -type f ! -name checks.log -print0 | while IFS= read -r -d '' f; do
        mkdir -p "$ROOT/$(dirname "$f")"; cp -p "$f" "$ROOT/$f"
      done )
  fi
  for f in "${CREATED[@]:-}"; do [ -n "$f" ] && rm -f "$ROOT/$f"; done
  bad "تم الاسترجاع. لم يتغيّر شيء في مشروعك. تفاصيل الفحص: $LOG"
  exit 1
}

# ── 1) فحوص أولية ───────────────────────────────────────────
say "── 1/4: فحوص أولية ──"
if [ ! -f "$ROOT/index.js" ] || [ ! -d "$ROOT/utils" ] || [ ! -f "$ROOT/package.json" ]; then
  bad "شغّل السكربت من جذر المشروع (يجب أن يحوي index.js و utils/ و package.json). لم يتغيّر شيء."; exit 2
fi
command -v node    >/dev/null 2>&1 || { bad "node غير موجود. لم يتغيّر شيء."; exit 2; }
command -v python3 >/dev/null 2>&1 || { bad "python3 غير موجود. لم يتغيّر شيء."; exit 2; }
for f in "${NEW_FILES[@]}"; do [ -f "$PACK/files/$f" ] || { bad "ملف ناقص في الحزمة: $f. لم يتغيّر شيء."; exit 2; }; done
if ! grep -q "applyCommandMenus" "$ROOT/index.js" && [ "$(grep -c 'startScheduler(bot, \[OWNER_ID\]);' "$ROOT/index.js")" != "1" ]; then
  bad "لم أجد نقطة الربط في index.js (startScheduler(bot, [OWNER_ID]); مرة واحدة). index.js عندك مختلف عن المتوقع. لم يتغيّر شيء."; exit 2
fi
ok "الفحوص الأولية سليمة (node $(node -v))"

# ── 2) نسخة احتياطية ────────────────────────────────────────
say "── 2/4: نسخة احتياطية ──"
mkdir -p "$BK"; : > "$LOG"
backup_one() {
  local f="$1"
  if [ -f "$ROOT/$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp -p "$ROOT/$f" "$BK/$f"
  else CREATED+=("$f"); fi
}
backup_one "index.js"; backup_one ".gitignore"
for f in "${NEW_FILES[@]}"; do backup_one "$f"; done
ok "النسخة الاحتياطية: backups/phase1-$STAMP/"

# ── 3) التطبيق ──────────────────────────────────────────────
say "── 3/4: نسخ الملفات وتعديل index.js ──"
for f in "${NEW_FILES[@]}"; do
  mkdir -p "$ROOT/$(dirname "$f")" && cp "$PACK/files/$f" "$ROOT/$f" || rollback
done
ok "نُسخت ${#NEW_FILES[@]} ملفات"
python3 "$PACK/patch_index.py" "$ROOT/index.js" || rollback
if [ -f "$ROOT/.gitignore" ] && ! grep -qx 'backups/' "$ROOT/.gitignore"; then printf '\nbackups/\n' >> "$ROOT/.gitignore"; fi

# ── 4) التحقق ───────────────────────────────────────────────
say "── 4/4: فحص الصياغة والاختبارات ──"
for f in index.js utils/command_registry.js utils/command_menu.js scripts/lib/command_scanner.js scripts/audit_commands.js test/command_registry.test.js; do
  node --check "$ROOT/$f" >> "$LOG" 2>&1 || { bad "خطأ صياغة في $f"; cat "$LOG" >&2; rollback; }
done
ok "الصياغة سليمة (6 ملفات)"

( cd "$ROOT" && node --test test/command_registry.test.js ) > "$LOG.tests" 2>&1; rc=$?
cat "$LOG.tests" >> "$LOG"
PASS="$(grep -E '^# pass' "$LOG.tests" | awk '{print $3}')"; FAIL="$(grep -E '^# fail' "$LOG.tests" | awk '{print $3}')"
if [ "$rc" -ne 0 ] || [ "${FAIL:-1}" != "0" ]; then
  bad "الاختبارات فشلت (نجح ${PASS:-?} وفشل ${FAIL:-?}):"; grep -E '^not ok' "$LOG.tests" | head -6 >&2
  echo "── تفاصيل الانحراف (من أداة التدقيق):" >&2
  ( cd "$ROOT" && node scripts/audit_commands.js 2>&1 | grep -E 'مفقود|ميت|بديل' ) >&2 || true
  rollback
fi
ok "الاختبارات: نجح $PASS / فشل $FAIL"

( cd "$ROOT" && node scripts/audit_commands.js ) >> "$LOG" 2>&1 || { bad "أداة التدقيق تُبلغ انحرافاً بين السجل والكود:"; tail -12 "$LOG" >&2; rollback; }
ok "أداة التدقيق: السجل متطابق مع الكود"

echo
ok "تم تطبيق المرحلة 1 بنجاح."
echo "  • القائمة تُرسل لتيليجرام عند الإقلاع. للتعطيل: COMMAND_MENU_SYNC=off"
echo "  • تقرير الصحة في أي وقت:  node scripts/audit_commands.js"
echo "  • التقرير الشامل:         docs/PHASE0_AUDIT_REPORT.md"
echo "  • التراجع اليدوي:         انسخ backups/phase1-$STAMP/index.js فوق index.js واحذف الملفات الجديدة"
echo "  • الخطوة التالية: git add . && git commit && git push ثم راقب اللوغ: [CommandMenu] تمت المزامنة: 4/4"
