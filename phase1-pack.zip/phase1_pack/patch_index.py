import sys
path = sys.argv[1] if len(sys.argv) > 1 else "index.js"
data = open(path, encoding='utf-8').read()
if "applyCommandMenus" in data:
    print("index.js: already patched")
else:
    anchor = "startScheduler(bot, [OWNER_ID]);"
    if data.count(anchor) != 1:
        raise SystemExit("index.js: anchor not found exactly once - no changes made")
    hook = ("require('./utils/command_menu').applyCommandMenus(bot.telegram)"
            ".catch((e) => logger.error('[CommandMenu] ' + e.message)); "
            "// قائمة الأوامر داخل تيليجرام (COMMAND_MENU_SYNC=off للتعطيل)\n\n    ")
    open(path, 'w', encoding='utf-8').write(data.replace(anchor, hook + anchor, 1))
    print("index.js: patched")
